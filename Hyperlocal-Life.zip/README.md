=== Hyperlocal Life Theme by BGRWeb.com ===

HMTL 5 and Genesis Framework 2.0.1+ compatible.
Github project link: https://github.com/prilldev/hyperlocal-life


=== Installation Instructions ===

1. Upload the theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking.


=== Theme Support ===

Check out http://bgrweb.com/hyperlocal-theme/ for more details on this theme.<br />
<em>** Requires various Genesis Plugins to be truly functional. Which ones? Ask me! ** </em><br />
<strong>Visit http://mywp.bgrweb.com/ for Managed WordPress hosting and paid support of this theme.</strong>
